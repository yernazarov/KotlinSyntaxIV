sealed class DataType {
    class DoubleType(val value: Double): DataType()
    class UnitType : DataType()
}
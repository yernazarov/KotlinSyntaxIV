fun main(args: Array<String>) {
    println(2.powerOf(3))
    val powerOfLambda = { x:Int -> println("The result is: $x")}
    3.powerOfNew(4, powerOfLambda)
    3.displayTypeInfo();
    "a".displayTypeInfo()
    true.displayTypeInfo()
    DataType.DoubleType(1.4).displayTypeInfo()
    DataType.UnitType().displayTypeInfo()
}

// Задача 1
fun Int.powerOf(power: Int) : Int{
    if (power==1) return this;
    return this*powerOf(power-1);
}

// Задача 2
fun Int.powerOfNew(power: Int, l: (Int) -> Unit) : Int {
    val x = powerOf(power)
    l(x);
    return x;
}

// Задача 3, 4
fun <T> T?.displayTypeInfo(): Unit {
    if (this is String) {
        println("Это String");
    } else if (this is Int) {
        println("Это Int");
    } else if (this is DataType.DoubleType) {
        println("это DoubleType со значением ${this.value}")
    } else if (this is DataType.UnitType) {
        println("это Unit");
    } else {
        println("тип у $this неизвестен");
    }
}